#include <stdio.h>
#define SIZE 100

int queue[SIZE], front = -1, rear = -1;

void enqueue(int val) {
    if(rear == SIZE - 1)
        printf("Full\n");
    else {
        if(front == -1) front = 0;
        queue[++rear] = val;
    }
}

void dequeue() {
    if(front == -1 || front > rear)
        printf("Empty\n");
    else
        printf("Removed: %d\n", queue[front++]);
}

void display() {
    if(front == -1 || front > rear)
        printf("Empty\n");
    else {
        int i;
        for(i=front;i<=rear;i++)
            printf("%d ", queue[i]);
        printf("\n");
    }
}

int main() {
    int ch, val;
    while(1) {
        printf("\n1.Enqueue 2.Dequeue 3.Display 4.Exit\nChoice: ");
        scanf("%d", &ch);
        if(ch==1) {
            printf("Enter value: ");
            scanf("%d", &val);
            enqueue(val);
        } else if(ch==2)
            dequeue();
        else if(ch==3)
            display();
        else break;
    }
    return 0;
}