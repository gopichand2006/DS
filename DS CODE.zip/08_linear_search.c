#include <stdio.h>
int main() {
    int a[100], n, key, i;
    printf("Enter size: ");
    scanf("%d", &n);
    printf("Enter elements:\n");
    for(i=0; i<n; i++)
        scanf("%d", &a[i]);
    printf("Enter key: ");
    scanf("%d", &key);
    for(i=0; i<n; i++) {
        if(a[i]==key) {
            printf("Found at %d\n", i+1);
            return 0;
        }
    }
    printf("Not found\n");
    return 0;
}