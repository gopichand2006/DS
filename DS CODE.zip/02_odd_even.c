#include <stdio.h>
int main() {
    int n, num, i;
    printf("How many numbers? ");
    scanf("%d", &n);
    for(i=0; i<n; i++) {
        printf("Enter number: ");
        scanf("%d", &num);
        if(num % 2 == 0)
            printf("Even\n");
        else
            printf("Odd\n");
    }
    return 0;
}