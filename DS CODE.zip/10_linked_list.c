#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *next;
};
struct Node *head = NULL;

void insert(int val) {
    struct Node *n = malloc(sizeof(struct Node));
    n->data = val; n->next = head; head = n;
}

void delete() {
    if(head == NULL) printf("Empty\n");
    else {
        struct Node *temp = head;
        head = head->next;
        free(temp);
    }
}

void display() {
    struct Node *t = head;
    while(t != NULL) {
        printf("%d -> ", t->data);
        t = t->next;
    }
    printf("NULL\n");
}

int main() {
    int ch, val;
    while(1) {
        printf("\n1.Insert 2.Delete 3.Display 4.Exit\nChoice: ");
        scanf("%d", &ch);
        if(ch==1) {
            printf("Enter value: ");
            scanf("%d", &val);
            insert(val);
        } else if(ch==2)
            delete();
        else if(ch==3)
            display();
        else break;
    }
    return 0;
}