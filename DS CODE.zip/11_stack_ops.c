#include <stdio.h>
#define SIZE 100

int stack[SIZE], top = -1;

void push(int val) {
    if(top == SIZE - 1)
        printf("Full\n");
    else
        stack[++top] = val;
}

void pop() {
    if(top == -1)
        printf("Empty\n");
    else
        printf("Popped: %d\n", stack[top--]);
}

void peek() {
    if(top == -1)
        printf("Empty\n");
    else
        printf("Top: %d\n", stack[top]);
}

int main() {
    int ch, val;
    while(1) {
        printf("\n1.Push 2.Pop 3.Peek 4.Exit\nChoice: ");
        scanf("%d", &ch);
        if(ch==1) {
            printf("Enter value: ");
            scanf("%d", &val);
            push(val);
        } else if(ch==2)
            pop();
        else if(ch==3)
            peek();
        else break;
    }
    return 0;
}